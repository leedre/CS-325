-How to run make change program-
python make_change.py
